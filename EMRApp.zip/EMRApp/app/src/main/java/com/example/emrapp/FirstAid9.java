package com.example.emrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirstAid9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid9);
        getSupportActionBar().setTitle("First Aid");
    }
}
