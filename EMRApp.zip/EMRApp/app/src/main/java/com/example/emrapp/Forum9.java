package com.example.emrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Forum9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum9);
        getSupportActionBar().setTitle("Forum");
    }
}
