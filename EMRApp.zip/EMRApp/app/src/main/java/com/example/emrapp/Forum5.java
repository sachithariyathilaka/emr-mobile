package com.example.emrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Forum5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum5);
        getSupportActionBar().setTitle("Forum");
    }
}
