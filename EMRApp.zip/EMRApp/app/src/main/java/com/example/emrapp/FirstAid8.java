package com.example.emrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirstAid8 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid8);
        getSupportActionBar().setTitle("First Aid");
    }
}
