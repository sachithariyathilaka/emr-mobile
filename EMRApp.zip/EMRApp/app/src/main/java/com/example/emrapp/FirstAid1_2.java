package com.example.emrapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class FirstAid1_2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_aid1_2);
    }
}
